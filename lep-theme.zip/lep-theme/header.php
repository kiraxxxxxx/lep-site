<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo('charset'); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<?php wp_head(); ?>
<link rel="icon" type="image/svg+xml" href="data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 32 32'><text y='28' font-size='28'>🌿</text></svg>">
</head>
<body <?php body_class(); ?>>
<div class="top-bar">Ethical Luxury</div>
<header class="site-header">
<div class="container">
  <a href="<?php echo home_url('/'); ?>" class="logo">LEP</a>
  <nav class="nav-links" id="navLinks">
    <?php
    $pages_nav = array(
        'HOME' => '/',
        'ABOUT' => '/about/',
        'TECHNOLOGY' => '/technology/',
        'PROJECTS' => '/projects/',
        'COMPANY' => '/company/',
        'NEWS' => '/news/',
        'FAQ' => '/faq/',
    );
    foreach ($pages_nav as $label => $slug) {
        $url = home_url($slug);
        $active = '';
        if (is_page(strtolower($label)) || ($label === 'HOME' && is_front_page())) {
            $active = ' class="active"';
        }
        echo "<a href=\"{$url}\"{$active}>{$label}</a>\n";
    }
    ?>
    <a href="<?php echo home_url('/contact/'); ?>" class="nav-cta">お問い合わせ</a>
  </nav>
  <button class="hamburger" onclick="document.getElementById('navLinks').classList.toggle('open')" aria-label="Menu">
    <span></span><span></span><span></span>
  </button>
</div>
</header>
