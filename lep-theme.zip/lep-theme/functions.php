<?php
/**
 * LEP Theme Functions
 */

// Theme setup
function lep_setup() {
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('custom-logo');
    add_theme_support('html5', array('search-form', 'comment-form', 'comment-list', 'gallery', 'caption'));
    
    register_nav_menus(array(
        'primary' => 'Primary Menu',
    ));
}
add_action('after_setup_theme', 'lep_setup');

// Enqueue styles
function lep_styles() {
    wp_enqueue_style('google-fonts', 'https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,400;0,600;0,700;1,400&family=Noto+Sans+JP:wght@300;400;500;700&family=Noto+Serif+JP:wght@400;600;700&display=swap', array(), null);
    wp_enqueue_style('lep-main', get_template_directory_uri() . '/assets/css/main.css', array('google-fonts'), '1.0');
    wp_enqueue_style('lep-wp', get_template_directory_uri() . '/assets/css/wp-overrides.css', array('lep-main'), '1.0');
}
add_action('wp_enqueue_scripts', 'lep_styles');

// Remove default WP stuff we don't need
remove_action('wp_head', 'wp_generator');
remove_action('wp_head', 'wlwmanifest_link');
remove_action('wp_head', 'rsd_link');

// Allow unfiltered HTML for admin (for page content with custom HTML)
function lep_allow_unfiltered_html($caps, $cap, $user_id) {
    if ('unfiltered_html' === $cap) {
        $caps = array('unfiltered_html' => true);
    }
    return $caps;
}
add_filter('map_meta_cap', 'lep_allow_unfiltered_html', 1, 3);

// Disable Gutenberg for pages (use classic editor style)
function lep_disable_gutenberg($use_block_editor, $post_type) {
    if ($post_type === 'page') return false;
    return $use_block_editor;
}
add_filter('use_block_editor_for_post_type', 'lep_disable_gutenberg', 10, 2);
