<section class="section-dark" style="padding:80px 0;text-align:center;">
  <div class="container" style="max-width:560px;">
    <p style="font-family:var(--serif);font-size:1.1rem;color:#fff;margin-bottom:8px;letter-spacing:0.06em;">生命の光を未来の灯りに</p>
    <p style="color:rgba(255,255,255,0.5);font-size:0.85rem;margin-bottom:32px;">持続可能な未来を推進しています。</p>
    <form style="display:flex;gap:0;max-width:420px;margin:0 auto;background:#fff;border-radius:40px;padding:6px 6px 6px 24px;align-items:center;">
      <input type="email" placeholder="メールアドレス" style="flex:1;border:none;outline:none;font-size:0.88rem;font-family:var(--sans);background:transparent;">
      <button type="submit" style="background:var(--lep-dark);color:#fff;border:none;padding:14px 28px;border-radius:32px;font-size:0.85rem;font-family:var(--sans);cursor:pointer;white-space:nowrap;">登録</button>
    </form>
  </div>
</section>

<footer class="site-footer">
<div class="container">
  <div class="footer-top">
    <div class="footer-brand">
      <div class="logo">LEP</div>
      <p>生命の叡智で、地球に癒しを。<br>LEPは自発光植物の社会実装を通じて、環境と調和した新しい光の文化を創造します。</p>
    </div>
    <div class="footer-col">
      <h4>Menu</h4>
      <a href="<?php echo home_url('/about/'); ?>">About</a>
      <a href="<?php echo home_url('/technology/'); ?>">Technology</a>
      <a href="<?php echo home_url('/projects/'); ?>">Projects</a>
      <a href="<?php echo home_url('/company/'); ?>">Company</a>
      <a href="<?php echo home_url('/news/'); ?>">News</a>
    </div>
    <div class="footer-col">
      <h4>Contact</h4>
      <a href="<?php echo home_url('/contact/'); ?>">お問い合わせ</a>
      <a href="mailto:info@start-lep.jp">info@start-lep.jp</a>
    </div>
  </div>
  <div class="footer-bottom">
    <span>&copy; <?php echo date('Y'); ?> LEP Inc. All rights reserved.</span>
    <div class="footer-sns">
      <a href="#" aria-label="Instagram">Instagram</a>
      <a href="#" aria-label="Facebook">Facebook</a>
      <a href="#" aria-label="X">X</a>
    </div>
  </div>
</div>
</footer>
<script>
document.querySelectorAll('.faq-item').forEach(item => {
  item.querySelector('.faq-q')?.addEventListener('click', () => {
    item.classList.toggle('open');
  });
});
</script>
<?php wp_footer(); ?>
</body>
</html>
